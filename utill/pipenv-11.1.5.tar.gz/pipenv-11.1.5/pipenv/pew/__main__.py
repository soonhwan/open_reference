from pipenv.patched import pew

if __name__ == '__main__':
    pew.pew.pew()
