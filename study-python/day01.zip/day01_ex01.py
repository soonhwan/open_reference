print('-'*25)
print('Hello python world')

# 이것은 반복문 이다.
for cnt in range(1,10):
    print('for 반복문')
    if cnt%2 == 0:
        print(cnt, '는 짝수')
    
