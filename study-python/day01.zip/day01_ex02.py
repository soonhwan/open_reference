# 파이썬
# day01_ex02.py

print("~"*40)
print("Python programming")
print("~"*40)
print("Hello Python world!")
