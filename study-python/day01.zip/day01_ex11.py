dict = {}
print(type(dict)) # dict

dict["name"] = "홍길동"
dict["phone"] = "010-7777-8888"
dict["addr"] = "서울시 은평구"

print(dict)
print("Name => " + dict["name"])
print("Phone => " + dict["phone"])
print("Addr => " + dict["addr"])
